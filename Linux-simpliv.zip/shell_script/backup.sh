#!/bin/bash
tar -czvf /backup/backup_$(date +%Y%m%d_%H%M%S).tar.gz /home/ubuntu