#!/bin/bash
if [ -f "aaa.txt" ]
then
    echo "File exists"
else
    echo "File does not exist"
fi