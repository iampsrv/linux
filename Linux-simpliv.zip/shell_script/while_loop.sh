while read line
do
  echo $line
done < input.txt